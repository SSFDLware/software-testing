//package bbTest;
//package bbTest;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

//import bubble.BubbleSort;

//import bubble.BubbleSort;
import java.util.Arrays;
public class bbTest {
	private BubbleSort b;
	@Before
	public void setup() throws Exception{
		b = new BubbleSort();
	}
	
	@After 
	public void down() throws Exception{
		b = null;
	}
	@Test
	public void SortTest() {
		assertEquals("[1, 2, 3, 4, 5]",Arrays.toString(BubbleSort.BubbleSort(new int[]{1,3,2,4,5})));
		assertEquals("[1, 2, 3, 4, 4, 5, 6, 9]",Arrays.toString(BubbleSort.BubbleSort(new int[]{1,3,2,4,5,6,4,9})));
		assertEquals("[0, 1, 2, 3, 4, 5]",Arrays.toString(BubbleSort.BubbleSort(new int[]{1,3,2,4,5,0})));
		assertEquals("[-1, 1, 2, 3, 4, 5]",Arrays.toString(BubbleSort.BubbleSort(new int[]{1,3,2,4,5,-1})));
	}
}
